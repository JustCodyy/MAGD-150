var img1;
var img2;

function preload() {
  img1 = loadImage("image1.jpg");
  img2 = loadImage("image2.jpg");
}

function setup() {
  createCanvas(400, 400);
  textFont("Calibri")
}

function draw() {
  background(220);
  textSize(24);
  fill(0);
  text("Hello p5.js", 150, 50);

 
  image(img1, mouseX, 250);
  image(img2, 200, mouseY, 400, 150);
 
}